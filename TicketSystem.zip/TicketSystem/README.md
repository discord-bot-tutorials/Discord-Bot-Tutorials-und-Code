English:
This system is only commented in German and not in English.
If an error occurs when starting the bot, please make sure that you have defined all variables correctly and that the bot is on the server. 

German:
Dieses System wird nur auf Deutsch und nicht auf Englisch kommentiert.
Falls bei dem starten des Bots ein Fehler auftritt schau bitte ob du alle Variablen richtig definiert hast und der Bot auf dem Server ist.