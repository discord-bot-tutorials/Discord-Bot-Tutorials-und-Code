const Discord = require('discord.js')
const fs = require('fs');
const config = JSON.parse(fs.readFileSync('config.json', 'utf8'));
const client = new Discord.Client();


const channelid = ["0000", "0000"]; //Du musst jeden Channel eingeben wo der Bot die Nachrichten sehen soll, also wenn eine Reaction dazu kommt. Neuer Channel = ... ["channelid1", "channelid2", "channelid3"]; für nur eine ... ["channelid1"] 
const messageid = "0000"; //Die Message auf die der Bot reagieren soll. Also wenn die Nachricht ist wo steht "Um ein Ticket zu eröffnen reagiere mit 🎫." Davon die ID halt...


client.on('ready', async function(){ 

channelid.forEach(async channelid => {

    await client.channels.cache.get(channelid).messages.fetch();

})

});

client.on('messageReactionAdd', async (reaction, user) => {

  if(reaction.emoji.name == '🎫' && reaction.message.id === messageid) {
      reaction.users.remove(user);
    
      reaction.message.guild.channels.create(`ticket-${user.username}`, {
          permissionOverwrites: [
              {
                  id: user.id,
                  allow: ["SEND_MESSAGES", "VIEW_CHANNEL"]
              },
              {
                  id: reaction.message.guild.roles.everyone,
                  deny: ["VIEW_CHANNEL"]
              }
          ],
          type: 'text'
      }).then(async channel => {
          channel.send(`<@${user.id}>`, new Discord.MessageEmbed().setTitle("Willkommen! Dein Ticket wurde eröffnet!").setDescription("Dir wird gleich geholfen.").setColor("FAFAFA"))
      })
    }
  
})
client.login(config.token)